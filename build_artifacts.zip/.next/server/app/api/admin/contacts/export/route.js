"use strict";(()=>{var e={};e.id=7081,e.ids=[7081,3994],e.modules={53524:e=>{e.exports=require("@prisma/client")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},80665:e=>{e.exports=require("dns")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},20066:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>E,patchFetch:()=>S,requestAsyncStorage:()=>g,routeModule:()=>d,serverHooks:()=>f,staticGenerationAsyncStorage:()=>h});var a={};t.r(a),t.d(a,{GET:()=>m,dynamic:()=>p,runtime:()=>l});var n=t(71707),i=t(93006),s=t(68467),o=t(66238),u=t(4568);let l="nodejs",p="force-dynamic",c=["name","email","phone","createdAt","agreePrivacy","agreeMarketing","totalBookings"];async function m(e){await (0,o.BI)();let{searchParams:r}=new URL(e.url),t=(0,u.yP)(r),a=await (0,u.e)({whereClause:t.whereClause,params:t.params,limit:10001,offset:0}),n=!1,i=a;a.length>1e4&&(n=!0,i=a.slice(0,1e4));let s=[];for(let e of(s.push(c.join(",")),i)){let r={name:e.name,email:e.email,phone:e.phone,createdAt:e.createdAt,agreePrivacy:e.agreePrivacy,agreeMarketing:e.agreeMarketing,totalBookings:e.totalBookings},t=c.map(e=>(function(e){if(null==e)return"";if(e instanceof Date)return e.toISOString();if("boolean"==typeof e)return e?"TRUE":"FALSE";let r=String(e).replace(/\r?\n/g," ");return/^[=+\-@]/.test(r)&&(r=`'${r}`),r=r.replace(/"/g,'""'),/[",]/.test(r)?`"${r}"`:r})(r[e])).join(",");s.push(t)}n&&s.push("# truncated");let l=new Headers;return l.set("Content-Type","text/csv"),l.set("Content-Disposition",'attachment; filename="contacts.csv"'),new Response(s.join("\n"),{status:200,headers:l})}let d=new n.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/admin/contacts/export/route",pathname:"/api/admin/contacts/export",filename:"route",bundlePath:"app/api/admin/contacts/export/route"},resolvedPagePath:"/Users/daniele/Documents/Lavoro/idola/Git/lasoluzione/src/app/api/admin/contacts/export/route.ts",nextConfigOutput:"",userland:a}),{requestAsyncStorage:g,staticGenerationAsyncStorage:h,serverHooks:f}=d,E="/api/admin/contacts/export/route";function S(){return(0,s.patchFetch)({serverHooks:f,staticGenerationAsyncStorage:h})}},71707:(e,r,t)=>{e.exports=t(30517)},4568:(e,r,t)=>{t.d(r,{JG:()=>s,e:()=>u,yP:()=>i});var a=t(73994);function n(e){return"true"===e||"false"!==e&&null}function i(e){let r=[],t=[],a=(e.get("search")??e.get("q")??"").trim();if(a){let e=`%${a.toLowerCase()}%`;r.push("(LOWER(name) LIKE ? OR LOWER(email) LIKE ? OR LOWER(phone) LIKE ?)"),t.push(e,e,e)}let i=n(e.get("newsletter"));null!==i&&(r.push("agreeMarketing = ?"),t.push(i?1:0));let s=n(e.get("privacy"));null!==s&&(r.push("agreePrivacy = ?"),t.push(s?1:0));let o=function(e){if(!e)return null;let r=new Date(e);return Number.isNaN(r.getTime())?null:(r.setHours(0,0,0,0),r.toISOString())}(e.get("from"));o&&(r.push("createdAt >= ?"),t.push(o));let u=function(e){if(!e)return null;let r=new Date(e);return Number.isNaN(r.getTime())?null:(r.setHours(23,59,59,999),r.toISOString())}(e.get("to"));return u&&(r.push("createdAt <= ?"),t.push(u)),{whereClause:r.length>0?r.join(" AND "):"1=1",params:t}}function s(e,r={}){let t=r.defaultPageSize??20,a=r.maxPageSize??100,n=Number.parseInt(e.get("page")??"1",10),i=Number.isNaN(n)||n<1?1:n,s=Number.parseInt(e.get("pageSize")??String(t),10),o=Math.min(Number.isNaN(s)||s<1?t:s,a);return{page:i,pageSize:o,skip:(i-1)*o}}function o(e){return{name:e.name?.trim()??"",email:e.email?.trim()??"",phone:e.phone?.trim()??"",createdAt:function(e){if(e instanceof Date)return e.toISOString();let r=new Date(e);return Number.isNaN(r.getTime())?new Date().toISOString():r.toISOString()}(e.createdAt),agreePrivacy:!!e.agreePrivacy,agreeMarketing:!!e.agreeMarketing,totalBookings:Number(e.totalBookings??0)}}async function u({whereClause:e,params:r,limit:t,offset:n=0}){let i=[...r];"number"==typeof t&&i.push(t,n);let s=`
    WITH filtered AS (
      SELECT
        id,
        name,
        TRIM(email) AS email,
        LOWER(TRIM(email)) AS normalizedEmail,
        phone,
        agreePrivacy,
        agreeMarketing,
        createdAt
      FROM Booking
      WHERE ${e}
    ),
    ranked AS (
      SELECT
        id,
        name,
        email,
        phone,
        agreePrivacy,
        agreeMarketing,
        createdAt,
        normalizedEmail,
        ROW_NUMBER() OVER (PARTITION BY normalizedEmail ORDER BY createdAt DESC, id DESC) AS rowNumber,
        COUNT(*) OVER (PARTITION BY normalizedEmail) AS totalBookings
      FROM filtered
    )
    SELECT
      name,
      email,
      phone,
      agreePrivacy,
      agreeMarketing,
      createdAt,
      totalBookings
    FROM ranked
    WHERE rowNumber = 1
    ORDER BY createdAt DESC${"number"==typeof t?" LIMIT ? OFFSET ?":""};
  `;return(await a.prisma.$queryRawUnsafe(s,...i)).map(o)}},50338:(e,r,t)=>{t.d(r,{v:()=>n});let a=null;function n(e){return!!e&&(function(){if(a)return a;let e=(process.env.ADMIN_EMAILS??"").split(",").map(e=>e.trim().toLowerCase()).filter(Boolean);return e.length||console.warn("[admin] ADMIN_EMAILS env var is empty. Admin access will be disabled."),a=e,e})().includes(e.trim().toLowerCase())}},66238:(e,r,t)=>{t.d(r,{BI:()=>s});var a=t(50338),n=t(89854);class i extends Error{constructor(e="User is not authorized to access admin resources"){super(e),this.name="AdminUnauthorizedError"}}async function s(){let e=await (0,n.I8)();if(!e?.user?.email||!(0,a.v)(e.user.email))throw new i;return e}},89854:(e,r,t)=>{t.d(r,{I8:()=>p,aH:()=>l});var a=t(44746),n=t(63547),i=t(46022),s=t(73994),o=t(50338);if(!process.env.NEXTAUTH_SECRET)throw Error("[Auth config] Missing NEXTAUTH_SECRET. Set NEXTAUTH_SECRET in .env.local");function u(e){let r=process.env[e];if(!r)throw Error(`Missing env var ${e} for Auth.js email provider`);return r}let l={adapter:(0,i.N)(s.prisma),session:{strategy:"jwt"},pages:{signIn:"/admin/signin",error:"/admin/not-authorized"},providers:[(0,n.Z)({from:u("MAIL_FROM"),server:{host:u("SMTP_HOST"),port:Number(process.env.SMTP_PORT||465),secure:465===Number(process.env.SMTP_PORT||465),auth:{user:u("SMTP_USER"),pass:u("SMTP_PASS")}},maxAge:600})],callbacks:{async signIn({user:e,email:r}){let t=r?.email,a=(e?.email??t??"").toLowerCase();if((0,o.v)(a))return!0;if(e?.id)try{await s.prisma.user.delete({where:{id:e.id}})}catch(e){console.warn("[auth] Failed to cleanup unauthorized user",e)}return!1},jwt:async({token:e})=>(e?.email&&(0,o.v)(String(e.email).toLowerCase())&&(e.role="admin"),e),session:async({session:e,token:r})=>(e.user&&(e.user.id=r.sub??e.user.id,e.user.role=r.role??"admin"),e)},trustHost:!0,secret:process.env.NEXTAUTH_SECRET},{auth:p,handlers:c,signIn:m,signOut:d}=(0,a.ZP)(l)},73994:(e,r,t)=>{t.r(r),t.d(r,{prisma:()=>n});var a=t(53524);let n=global.prisma??new a.PrismaClient({log:["error"]})}};var r=require("../../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),a=r.X(0,[1141,4033,629,6338],()=>t(20066));module.exports=a})();