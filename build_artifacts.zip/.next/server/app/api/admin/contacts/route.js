"use strict";(()=>{var e={};e.id=3984,e.ids=[3984,3994],e.modules={53524:e=>{e.exports=require("@prisma/client")},72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},80665:e=>{e.exports=require("dns")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},70379:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>S,patchFetch:()=>f,requestAsyncStorage:()=>g,routeModule:()=>d,serverHooks:()=>E,staticGenerationAsyncStorage:()=>h});var a={};t.r(a),t.d(a,{GET:()=>c,dynamic:()=>m,runtime:()=>p});var i=t(71707),n=t(93006),s=t(68467),o=t(34033),u=t(66238),l=t(4568);let p="nodejs",m="force-dynamic";async function c(e){await (0,u.BI)();let{searchParams:r}=new URL(e.url),a=(0,l.yP)(r),{page:i,pageSize:n,skip:s}=(0,l.JG)(r),[p,m]=await Promise.all([(0,l.e)({whereClause:a.whereClause,params:a.params,limit:n,offset:s}),(await Promise.resolve().then(t.bind(t,73994))).prisma.$queryRawUnsafe(`SELECT COUNT(DISTINCT LOWER(TRIM(email))) AS total FROM Booking WHERE ${a.whereClause};`,...a.params)]),c=Number(m[0]?.total??0),d=Math.ceil(c/n)||1;return o.NextResponse.json({data:p,meta:{page:i,pageSize:n,total:c,totalPages:d,hasNextPage:i<d,hasPreviousPage:i>1}})}let d=new i.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/admin/contacts/route",pathname:"/api/admin/contacts",filename:"route",bundlePath:"app/api/admin/contacts/route"},resolvedPagePath:"/Users/daniele/Documents/Lavoro/idola/Git/lasoluzione/src/app/api/admin/contacts/route.ts",nextConfigOutput:"",userland:a}),{requestAsyncStorage:g,staticGenerationAsyncStorage:h,serverHooks:E}=d,S="/api/admin/contacts/route";function f(){return(0,s.patchFetch)({serverHooks:E,staticGenerationAsyncStorage:h})}},71707:(e,r,t)=>{e.exports=t(30517)},4568:(e,r,t)=>{t.d(r,{JG:()=>s,e:()=>u,yP:()=>n});var a=t(73994);function i(e){return"true"===e||"false"!==e&&null}function n(e){let r=[],t=[],a=(e.get("search")??e.get("q")??"").trim();if(a){let e=`%${a.toLowerCase()}%`;r.push("(LOWER(name) LIKE ? OR LOWER(email) LIKE ? OR LOWER(phone) LIKE ?)"),t.push(e,e,e)}let n=i(e.get("newsletter"));null!==n&&(r.push("agreeMarketing = ?"),t.push(n?1:0));let s=i(e.get("privacy"));null!==s&&(r.push("agreePrivacy = ?"),t.push(s?1:0));let o=function(e){if(!e)return null;let r=new Date(e);return Number.isNaN(r.getTime())?null:(r.setHours(0,0,0,0),r.toISOString())}(e.get("from"));o&&(r.push("createdAt >= ?"),t.push(o));let u=function(e){if(!e)return null;let r=new Date(e);return Number.isNaN(r.getTime())?null:(r.setHours(23,59,59,999),r.toISOString())}(e.get("to"));return u&&(r.push("createdAt <= ?"),t.push(u)),{whereClause:r.length>0?r.join(" AND "):"1=1",params:t}}function s(e,r={}){let t=r.defaultPageSize??20,a=r.maxPageSize??100,i=Number.parseInt(e.get("page")??"1",10),n=Number.isNaN(i)||i<1?1:i,s=Number.parseInt(e.get("pageSize")??String(t),10),o=Math.min(Number.isNaN(s)||s<1?t:s,a);return{page:n,pageSize:o,skip:(n-1)*o}}function o(e){return{name:e.name?.trim()??"",email:e.email?.trim()??"",phone:e.phone?.trim()??"",createdAt:function(e){if(e instanceof Date)return e.toISOString();let r=new Date(e);return Number.isNaN(r.getTime())?new Date().toISOString():r.toISOString()}(e.createdAt),agreePrivacy:!!e.agreePrivacy,agreeMarketing:!!e.agreeMarketing,totalBookings:Number(e.totalBookings??0)}}async function u({whereClause:e,params:r,limit:t,offset:i=0}){let n=[...r];"number"==typeof t&&n.push(t,i);let s=`
    WITH filtered AS (
      SELECT
        id,
        name,
        TRIM(email) AS email,
        LOWER(TRIM(email)) AS normalizedEmail,
        phone,
        agreePrivacy,
        agreeMarketing,
        createdAt
      FROM Booking
      WHERE ${e}
    ),
    ranked AS (
      SELECT
        id,
        name,
        email,
        phone,
        agreePrivacy,
        agreeMarketing,
        createdAt,
        normalizedEmail,
        ROW_NUMBER() OVER (PARTITION BY normalizedEmail ORDER BY createdAt DESC, id DESC) AS rowNumber,
        COUNT(*) OVER (PARTITION BY normalizedEmail) AS totalBookings
      FROM filtered
    )
    SELECT
      name,
      email,
      phone,
      agreePrivacy,
      agreeMarketing,
      createdAt,
      totalBookings
    FROM ranked
    WHERE rowNumber = 1
    ORDER BY createdAt DESC${"number"==typeof t?" LIMIT ? OFFSET ?":""};
  `;return(await a.prisma.$queryRawUnsafe(s,...n)).map(o)}},50338:(e,r,t)=>{t.d(r,{v:()=>i});let a=null;function i(e){return!!e&&(function(){if(a)return a;let e=(process.env.ADMIN_EMAILS??"").split(",").map(e=>e.trim().toLowerCase()).filter(Boolean);return e.length||console.warn("[admin] ADMIN_EMAILS env var is empty. Admin access will be disabled."),a=e,e})().includes(e.trim().toLowerCase())}},66238:(e,r,t)=>{t.d(r,{BI:()=>s});var a=t(50338),i=t(89854);class n extends Error{constructor(e="User is not authorized to access admin resources"){super(e),this.name="AdminUnauthorizedError"}}async function s(){let e=await (0,i.I8)();if(!e?.user?.email||!(0,a.v)(e.user.email))throw new n;return e}},89854:(e,r,t)=>{t.d(r,{I8:()=>p,aH:()=>l});var a=t(44746),i=t(63547),n=t(46022),s=t(73994),o=t(50338);if(!process.env.NEXTAUTH_SECRET)throw Error("[Auth config] Missing NEXTAUTH_SECRET. Set NEXTAUTH_SECRET in .env.local");function u(e){let r=process.env[e];if(!r)throw Error(`Missing env var ${e} for Auth.js email provider`);return r}let l={adapter:(0,n.N)(s.prisma),session:{strategy:"jwt"},pages:{signIn:"/admin/signin",error:"/admin/not-authorized"},providers:[(0,i.Z)({from:u("MAIL_FROM"),server:{host:u("SMTP_HOST"),port:Number(process.env.SMTP_PORT||465),secure:465===Number(process.env.SMTP_PORT||465),auth:{user:u("SMTP_USER"),pass:u("SMTP_PASS")}},maxAge:600})],callbacks:{async signIn({user:e,email:r}){let t=r?.email,a=(e?.email??t??"").toLowerCase();if((0,o.v)(a))return!0;if(e?.id)try{await s.prisma.user.delete({where:{id:e.id}})}catch(e){console.warn("[auth] Failed to cleanup unauthorized user",e)}return!1},jwt:async({token:e})=>(e?.email&&(0,o.v)(String(e.email).toLowerCase())&&(e.role="admin"),e),session:async({session:e,token:r})=>(e.user&&(e.user.id=r.sub??e.user.id,e.user.role=r.role??"admin"),e)},trustHost:!0,secret:process.env.NEXTAUTH_SECRET},{auth:p,handlers:m,signIn:c,signOut:d}=(0,a.ZP)(l)},73994:(e,r,t)=>{t.r(r),t.d(r,{prisma:()=>i});var a=t(53524);let i=global.prisma??new a.PrismaClient({log:["error"]})}};var r=require("../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),a=r.X(0,[1141,4033,629,6338],()=>t(70379));module.exports=a})();