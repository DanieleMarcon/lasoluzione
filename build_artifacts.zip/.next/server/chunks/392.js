"use strict";exports.id=392,exports.ids=[392,3994],exports.modules={11090:(e,o,n)=>{n.d(o,{B_:()=>L,NY:()=>y,PM:()=>C,PN:()=>v,_g:()=>k,g6:()=>E,h4:()=>c,it:()=>q,od:()=>x,uq:()=>$});var t=n(30629);let{SMTP_HOST:r,SMTP_PORT:i,SMTP_USER:a,SMTP_PASS:l,MAIL_FROM:s,MAIL_TO_BOOKINGS:m}=process.env,p=null;function d(){return!!(r&&i&&a&&l&&s)}function c(){if(p)return p;if(!d())throw Error("SMTP env vars mancanti: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, MAIL_FROM");let e=Number(i);return p=t.createTransport({host:r,port:e,secure:465===e,auth:{user:a,pass:l}})}function g(e){if(!e)return null;let o=e.trim();return o.length?o:null}function u(e,o){let n=e?e.trim().replace(/\/$/,""):"";return n?`${n}${o}`:o}function f(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}async function $(e){let o=g(e.to);if(!o){console.warn("[mailer] sendBookingVerifyEmail skipped: destinatario mancante",{bookingId:e.bookingId});return}if(!d()||!s){console.info("[mailer] sendBookingVerifyEmail skipped (SMTP non configurato)",{bookingId:e.bookingId,to:o});return}let n=await I(),t=new URLSearchParams({token:e.token}),r=`/api/bookings/confirm?${t.toString()}`,i=u(e.baseUrl,r),a=e.eventTitle?.trim()?f(e.eventTitle.trim()):"La Soluzione",l=e.whenLabel?.trim(),m=`
    <div style="font-family:'Helvetica Neue',Arial,sans-serif;color:#0f172a;">
      <p style="margin:0 0 0.75rem;">Ciao,</p>
      <p style="margin:0 0 1rem;">Per completare la prenotazione #${f(String(e.bookingId))} per <strong>${a}</strong>${l?` del <strong>${f(l)}</strong>`:""} clicca sul pulsante qui sotto.</p>
      <p style="margin:1.5rem 0;">
        <a href="${i}" style="background:#2563eb;color:#fff;padding:0.75rem 1.25rem;border-radius:999px;text-decoration:none;font-weight:600;">Conferma la tua prenotazione</a>
      </p>
      <p style="margin:0 0 0.75rem;color:#475569;">Se il pulsante non funziona copia e incolla questo link nel browser:</p>
      <p style="margin:0 0 1.5rem;"><a href="${i}" style="color:#2563eb;word-break:break-all;">${i}</a></p>
      <p style="margin:0;color:#94a3b8;">Se non hai richiesto questa prenotazione puoi ignorare questo messaggio.</p>
    </div>
  `,p=[`Conferma la prenotazione #${e.bookingId} per ${e.eventTitle?.trim()||"La Soluzione"}.`,e.whenLabel?.trim()?`Quando: ${e.whenLabel.trim()}`:"",i,"Se non hai richiesto questa prenotazione ignora questo messaggio."].filter(Boolean),c=await n.sendMail({from:s,to:o,subject:"Conferma la tua prenotazione",html:m,text:p.join("\n")});console.info("[mailer] sendBookingVerifyEmail sent",{messageId:c?.messageId??null,bookingId:e.bookingId})}async function y(e){let o=g(e.to);if(!o){console.warn("[mailer] sendOrderEmailVerifyLink skipped: destinatario mancante");return}if(!d()||!s){console.info("[mailer] sendOrderEmailVerifyLink skipped (SMTP non configurato)",{to:o});return}let n=await I(),t=e.name?.trim(),r=t?` ${f(t)}`:"",i=t?` ${t}`:"",a=`
    <div style="font-family:'Helvetica Neue',Arial,sans-serif;color:#0f172a;">
      <p style="margin:0 0 0.75rem;">Ciao${r},</p>
      <p style="margin:0 0 1rem;">per confermare il tuo ordine clicca qui:</p>
      <p style="margin:1.5rem 0;">
        <a href="${e.verifyUrl}" style="background:#2563eb;color:#fff;padding:0.75rem 1.25rem;border-radius:999px;text-decoration:none;font-weight:600;">Conferma il tuo ordine</a>
      </p>
      <p style="margin:0 0 1.5rem;color:#475569;">Il link scade tra 15 minuti. Se il pulsante non funziona copia e incolla questo link nel browser:</p>
      <p style="margin:0 0 1.5rem;"><a href="${e.verifyUrl}" style="color:#2563eb;word-break:break-all;">${e.verifyUrl}</a></p>
      <p style="margin:0;color:#94a3b8;">Se non hai richiesto questo ordine puoi ignorare questo messaggio.</p>
    </div>
  `,l=[`Ciao${i},`,"","per confermare il tuo ordine clicca qui:",e.verifyUrl,"","Il link scade tra 15 minuti. Se non hai richiesto questo ordine ignora questa email."].join("\n"),m=await n.sendMail({from:s,to:o,subject:"Conferma il tuo ordine",html:a,text:l});console.info("[mailer] sendOrderEmailVerifyLink sent",{messageId:m?.messageId??null})}async function h(e){let o=g(e.to);if(!o){console.warn("[mailer] sendBookingConfirmedCustomer skipped: destinatario mancante",{bookingId:e.bookingId});return}if(!d()||!s){console.info("[mailer] sendBookingConfirmedCustomer skipped (SMTP non configurato)",{bookingId:e.bookingId,to:o});return}let n=await I(),t=`/checkout/confirmed?bookingId=${encodeURIComponent(String(e.bookingId))}`,r=u(e.baseUrl,t),i=e.whenLabel?.trim(),a=e.eventTitle?.trim()?f(e.eventTitle.trim()):"La Soluzione",l=`
    <div style="font-family:'Helvetica Neue',Arial,sans-serif;color:#0f172a;">
      <p style="margin:0 0 0.75rem;">Ciao,</p>
      <p style="margin:0 0 1rem;">La prenotazione #${f(String(e.bookingId))} per <strong>${a}</strong>${i?` del <strong>${f(i)}</strong>`:""} \xe8 stata confermata.</p>
      <ul style="padding-left:1.25rem;margin:0 0 1.25rem;">
        <li><strong>Persone:</strong> ${e.people}</li>
        ${i?`<li><strong>Quando:</strong> ${f(i)}</li>`:""}
      </ul>
      <p style="margin:1.5rem 0 0.75rem;">
        <a href="${r}" style="background:#2563eb;color:#fff;padding:0.75rem 1.25rem;border-radius:999px;text-decoration:none;font-weight:600;">Dettagli</a>
      </p>
      <p style="margin:0;color:#475569;">Ti aspettiamo!</p>
    </div>
  `,m=[`La prenotazione #${e.bookingId} \xe8 confermata.`,`Evento: ${e.eventTitle?.trim()||"La Soluzione"}`,i?`Quando: ${i}`:"",`Persone: ${e.people}`,`Dettagli: ${r}`].filter(Boolean),p=await n.sendMail({from:s,to:o,subject:"Prenotazione confermata",html:l,text:m.join("\n")});console.info("[mailer] sendBookingConfirmedCustomer sent",{messageId:p?.messageId??null,bookingId:e.bookingId})}async function b(e){let o=g(e.to);if(!o){console.warn("[mailer] sendBookingConfirmedAdmin skipped: destinatario mancante",{bookingId:e.bookingId});return}if(!d()||!s){console.info("[mailer] sendBookingConfirmedAdmin skipped (SMTP non configurato)",{bookingId:e.bookingId,to:o});return}let n=await I(),t=e.whenLabel?.trim(),r=`
    <div style="font-family:'Helvetica Neue',Arial,sans-serif;color:#0f172a;">
      <p style="margin:0 0 0.5rem;">Prenotazione confermata.</p>
      <ul style="padding-left:1.25rem;margin:0 0 0.75rem;">
        <li><strong>ID:</strong> #${f(String(e.bookingId))}</li>
        <li><strong>Evento:</strong> ${f(e.eventTitle)}</li>
        ${t?`<li><strong>Quando:</strong> ${f(t)}</li>`:""}
        <li><strong>Persone:</strong> ${e.people}</li>
        <li><strong>Cliente:</strong> ${f(e.customerName)} (${f(e.customerEmail)}${e.customerPhone?`, ${f(e.customerPhone)}`:""})</li>
      </ul>
    </div>
  `,i=[`Prenotazione confermata #${e.bookingId}`,`Evento: ${e.eventTitle}`,t?`Quando: ${t}`:"",`Persone: ${e.people}`,`Cliente: ${e.customerName} (${e.customerEmail}${e.customerPhone?`, ${e.customerPhone}`:""})`].filter(Boolean),a=await n.sendMail({from:s,to:o,subject:"Nuova prenotazione confermata",html:r,text:i.join("\n")});console.info("[mailer] sendBookingConfirmedAdmin sent",{messageId:a?.messageId??null,bookingId:e.bookingId})}async function k(e){var o;await h({to:e.customerEmail,bookingId:e.bookingId,eventTitle:e.eventTitle??"La Soluzione",whenLabel:e.whenLabel??"",people:e.people??1,baseUrl:(o=e.baseUrl)&&o.trim()?o.trim().replace(/\/$/,""):"http://localhost:3000".trim().replace(/\/$/,"")})}async function v(e){await b({to:e.adminEmail,bookingId:e.bookingId,customerName:e.customerName??"Cliente",customerEmail:e.customerEmail,customerPhone:e.customerPhone??"",eventTitle:e.eventTitle??"La Soluzione",whenLabel:e.whenLabel??"",people:e.people??1})}async function C(e){let o=c();try{await o.verify()}catch(e){throw console.error("[mailer.verify] errore:",e),e}let n=new Date(e.date).toLocaleString("it-IT",{weekday:"short",day:"2-digit",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"}),t=e=>(e/100).toLocaleString("it-IT",{style:"currency",currency:"EUR"}),r=(()=>{if(!e.lunch)return"";let o=e.lunch.coverCents*e.people,n=e.lunch.items.filter(e=>e.qty>0).map(e=>{let o=t(e.priceCents*e.qty);return`  • ${e.qty}\xd7 ${e.name} – ${t(e.priceCents)} cad. (Tot ${o})`}).join("\n");return`
Selezione pranzo:
${n}
Coperto (${t(e.lunch.coverCents)} x ${e.people}): ${t(o)}
Totale pranzo: ${t(e.lunch.totalCents)}
`})(),i=(()=>{if(!e.lunch)return"";let o=e.lunch.coverCents*e.people,n=e.lunch.items.filter(e=>e.qty>0).map(e=>{let o=t(e.priceCents*e.qty);return`<li>${e.qty} \xd7 ${e.name} — <strong>${t(e.priceCents)}</strong> cad. (Tot <strong>${o}</strong>)</li>`}).join("");return`
      <h3 style="margin-top:1.5rem;">Selezione pranzo</h3>
      <ul>${n}</ul>
      <p><strong>Coperto:</strong> ${t(e.lunch.coverCents)} \xd7 ${e.people} = ${t(o)}</p>
      <p><strong>Totale pranzo:</strong> ${t(e.lunch.totalCents)}</p>
    `})(),a=(()=>{let o=e.dinner;if(!o||!Array.isArray(o.items)||null==o.totalCents)return"";let n=o.items.filter(e=>e&&e.qty>0).map(e=>{let o=e.priceCents*e.qty;return`• ${e.qty} \xd7 ${e.name} — ${t(o)}`}).join("\n");return`
--- CENA ---
${n}
Coperto: ${t(o.coverCents)}
Totale cena: ${t(o.totalCents)}
`})(),l=(()=>{if(!e.dinner)return"";let o=e.dinner.coverCents*e.people,n=e.dinner.items.filter(e=>e.qty>0).map(e=>{let o=t(e.priceCents*e.qty);return`<li>${e.qty} \xd7 ${e.name} — <strong>${t(e.priceCents)}</strong> cad. (Tot <strong>${o}</strong>)</li>`}).join("");return`
      <h3 style="margin-top:1.5rem;">Selezione cena</h3>
      <ul>${n}</ul>
      <p><strong>Coperto:</strong> ${t(e.dinner.coverCents)} \xd7 ${e.people} = ${t(o)}</p>
      <p><strong>Totale cena:</strong> ${t(e.dinner.totalCents)}</p>
    `})(),p=e.tierLabel&&"number"==typeof e.tierPriceCents,d=p?`
Opzione: ${e.tierLabel} (${t(e.tierPriceCents)})
`:e.tierLabel?`
Opzione: ${e.tierLabel}
`:"",g=p?`<li><strong>Opzione:</strong> ${e.tierLabel} (${t(e.tierPriceCents)})</li>`:e.tierLabel?`<li><strong>Opzione:</strong> ${e.tierLabel}</li>`:"";await o.sendMail({from:s,to:e.email,subject:`Prenotazione ricevuta – Bar La Soluzione (#${e.id})`,text:`Ciao ${e.name},

abbiamo ricevuto la tua prenotazione:

• Data/Ora: ${n}
• Persone: ${e.people}
${e.phone?`• Telefono: ${e.phone}
`:""}${e.notes?`• Note: ${e.notes}
`:""}${d}${r}${a}

Presentati in cassa dicendo:
“Prenotazione a nome ${e.name}, numero ${e.people}, codice #${e.id}”.

A presto!
Bar La Soluzione
`,html:`<p>Ciao <strong>${e.name}</strong>,</p>
<p>Abbiamo ricevuto la tua prenotazione:</p>
<ul>
  <li><strong>Data/Ora:</strong> ${n}</li>
  <li><strong>Persone:</strong> ${e.people}</li>
  ${e.phone?`<li><strong>Telefono:</strong> ${e.phone}</li>`:""}
  ${e.notes?`<li><strong>Note:</strong> ${e.notes}</li>`:""}
  ${g}
</ul>
${i}
${l}
<p>In cassa comunica:<br/><em>“Prenotazione a nome ${e.name}, ${e.people} persone, codice #${e.id}”.</em></p>
<p>A presto!<br/>Bar La Soluzione</p>`}),await o.sendMail({from:s,to:m||"info@lasoluzione.eu",subject:`Nuova prenotazione #${e.id} – ${e.name} (${e.people}p)`,text:`Nuova prenotazione:

ID: ${e.id}
Data/Ora: ${n}
Persone: ${e.people}
Nome: ${e.name}
Email: ${e.email}
${e.phone?`Telefono: ${e.phone}
`:""}${e.notes?`Note: ${e.notes}
`:""}${d}${r}${a}`})}async function I(){let e=c();try{await e.verify()}catch(e){console.warn("[mailer] verify SMTP fallita, continuo",e)}return e}function P(e,o){let n=e.reduce((e,o)=>e+o.priceCents*o.qty,0);return n>0?n:"number"==typeof o?o:0}function w(e){if(0===e.length)return"";let o=e.map(e=>`<li>${e.qty} \xd7 ${e.name} — <strong>${N(e.priceCents*e.qty)}</strong></li>`).join("");return`<ul>${o}</ul>`}function S(e){return 0===e.length?"":e.map(e=>`• ${e.qty} \xd7 ${e.name} — ${N(e.priceCents*e.qty)}`).join("\n")}function z(e){return e?e.length<=8?e.toUpperCase():e.slice(-8).toUpperCase():""}function T(){let e=new Set,o=process.env.ADMIN_EMAILS;return o&&o.split(",").map(e=>e.trim()).filter(Boolean).forEach(o=>e.add(o)),m&&e.add(m),!e.size&&s&&e.add(s),Array.from(e)}async function L({to:e,order:o,items:n}){let t=(e||o.email)?.trim();if(!t){console.warn("[mailer] conferma ordine non inviata: destinatario mancante",{orderId:o.id});return}if(!d()||!s){console.info("[mailer] sendOrderConfirmation skipped (SMTP non configurato)",{to:t,orderId:o.id});return}let r=await I(),i=P(n,o.totalCents),a=`${"http://localhost:3000".replace(/\/$/,"")}/checkout/return?orderId=${encodeURIComponent(o.id)}`,l=`Conferma ordine #${z(o.id)} – La Soluzione`,m=w(n),p=S(n),c=`
    <div style="font-family: 'Helvetica Neue', Arial, sans-serif; color: #0f172a;">
      <h1 style="font-size: 1.35rem; margin-bottom: 0.5rem;">Grazie per l’ordine</h1>
      <p style="margin: 0 0 1rem;">Ordine <strong>#${o.id}</strong> a nome <strong>${o.name}</strong>.</p>
      <p style="margin: 0 0 1rem;">Totale: <strong>${N(i)}</strong></p>
      ${m?`<h2 style="font-size:1.05rem; margin-top:1.5rem;">Dettaglio prodotti</h2>${m}`:""}
      ${o.notes?`<p style="margin-top:1rem;"><strong>Note:</strong> ${o.notes}</p>`:""}
      <p style="margin-top:1.5rem;">Telefono: ${o.phone??"non fornito"}</p>
      <p style="margin-top:2rem;"><a href="${a}" style="color:#2563eb; font-weight:600;">Rivedi ordine</a></p>
      <p style="margin-top:2rem; color:#475569;">A presto!<br/>La Soluzione</p>
    </div>
  `,g=[`Grazie per l’ordine #${o.id}.`,`Totale: ${N(i)}.`,p,o.notes?`Note: ${o.notes}`:"",`Telefono: ${o.phone??"non fornito"}`,`Rivedi ordine: ${a}`].filter(Boolean).join("\n\n");await r.sendMail({from:s,to:t,subject:l,html:c,text:g})}async function q({order:e,items:o,booking:n}){let t=T();if(0===t.length){console.warn("[mailer] notifica admin non inviata: nessun destinatario");return}if(!d()||!s){console.info("[mailer] sendOrderNotificationToAdmin skipped (SMTP non configurato)",{orderId:e.id,to:t});return}let r=await I(),i=P(o,e.totalCents),a=w(o),l=S(o),m=n?.date?new Date(n.date).toLocaleString("it-IT",{day:"2-digit",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"}):null,p=`Nuovo ordine #${z(e.id)} (${N(i)})`,c=`
    <div style="font-family: 'Helvetica Neue', Arial, sans-serif; color: #0f172a;">
      <h1 style="font-size: 1.25rem;">Nuovo ordine ricevuto</h1>
      <p><strong>#${e.id}</strong> – ${e.name} (${e.email}${e.phone?`, ${e.phone}`:""})</p>
      <p><strong>Totale:</strong> ${N(i)}</p>
      ${m?`<p><strong>Data:</strong> ${m}</p>`:""}
      ${"number"==typeof n?.people?`<p><strong>Persone:</strong> ${n.people}</p>`:""}
      ${a?`<h2 style="font-size:1.05rem; margin-top:1.5rem;">Dettaglio</h2>${a}`:""}
      ${e.notes?`<p style="margin-top:1rem;"><strong>Note cliente:</strong> ${e.notes}</p>`:""}
    </div>
  `,g=[`Nuovo ordine #${e.id}`,`Cliente: ${e.name} (${e.email}${e.phone?`, ${e.phone}`:""})`,`Totale: ${N(i)}`,m?`Data: ${m}`:"","number"==typeof n?.people?`Persone: ${n.people}`:"",l,e.notes?`Note cliente: ${e.notes}`:""].filter(Boolean).join("\n");await r.sendMail({from:s,to:t,subject:p,html:c,text:g})}async function x({order:e,reason:o}){let n=`Problema con l’ordine #${z(e.id)} – La Soluzione`,t=o?o.toString():"transazione non completata";if(e.email&&d()&&s){let o=await I(),r=`Ciao ${e.name??""},

abbiamo riscontrato un problema con il pagamento dell’ordine #${e.id}.

Dettagli: ${t}.

Se il pagamento \xe8 andato a buon fine contattaci rispondendo a questa email.`,i=`
      <p>Ciao ${e.name??""},</p>
      <p>abbiamo riscontrato un problema con il pagamento dell’ordine <strong>#${e.id}</strong>.</p>
      <p>Dettagli: <strong>${t}</strong>.</p>
      <p>Se hai gi\xe0 completato il pagamento rispondi a questa email o contattaci telefonicamente.</p>
    `;await o.sendMail({from:s,to:e.email,subject:n,text:r,html:i})}else console.info("[mailer] ordine fallito: email cliente non inviata",{orderId:e.id});let r=T();if(r.length&&d()&&s){let o=await I();await o.sendMail({from:s,to:r,subject:n,text:`Ordine #${e.id} non completato. Motivo: ${t}.`})}}let M=new Intl.NumberFormat("it-IT",{style:"currency",currency:"EUR"});function N(e){return M.format(e/100)}async function E(e){let o=`Completa il pagamento del tuo ordine #${e.orderId}`,n=N(e.amountCents),t=e.hostedPaymentUrl?`<p style="margin:2rem 0; text-align:center;"><a href="${e.hostedPaymentUrl}" style="display:inline-block;padding:0.85rem 1.75rem;border-radius:999px;background:#14532d;color:#fff;font-weight:600;text-decoration:none;">Paga ora</a></p>`:"",r=e.hostedPaymentUrl?`Paga ora: ${e.hostedPaymentUrl}`:"Accedi alla tua area personale per completare il pagamento.",i=`Ciao,

abbiamo creato il tuo ordine #${e.orderId} per un totale di ${n}.

${r}

Se hai gi\xe0 pagato ignora questo messaggio.`,a=`
    <p>Ciao,</p>
    <p>abbiamo creato il tuo ordine <strong>#${e.orderId}</strong> per un totale di <strong>${n}</strong>.</p>
    ${t||""}
    ${e.hostedPaymentUrl?`<p style="text-align:center; color:#6b7280; font-size:0.95rem;">Se il pulsante non funziona copia e incolla questo link nel browser:<br /><a href="${e.hostedPaymentUrl}">${e.hostedPaymentUrl}</a></p>`:""}
    <p style="margin-top:2rem; color:#475569;">Se hai gi\xe0 completato il pagamento puoi ignorare questa email.</p>
    <p style="margin-top:1.5rem;">Grazie!<br/>Bar La Soluzione</p>
  `;if(!d()||!s)return console.info("[mailer] sendOrderPaymentEmail skipped (SMTP non configurato)",{to:e.to,subject:o,text:i,hostedPaymentUrl:e.hostedPaymentUrl}),{ok:!1,skipped:!0,error:"SMTP non configurato"};try{let n=c();try{await n.verify()}catch(e){console.warn("[mailer] verify SMTP failed, continuo con invio",e)}let t=await n.sendMail({from:s,to:e.to,subject:o,text:i,html:a});return{ok:!0,messageId:t.messageId}}catch(o){let e=o instanceof Error?o.message:String(o);return console.error("[mailer] sendOrderPaymentEmail error",o),{ok:!1,error:e}}}},73994:(e,o,n)=>{n.r(o),n.d(o,{prisma:()=>r});var t=n(53524);let r=global.prisma??new t.PrismaClient({log:["error"]})}};